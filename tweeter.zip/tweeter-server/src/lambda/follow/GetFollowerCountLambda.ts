import { CountResponse, FollowServiceGeneralRequest, User } from "tweeter-shared";
import { FollowService } from "../../model/service/FollowService";

export const handler = async (request: FollowServiceGeneralRequest): Promise<CountResponse> => {
    const followService = new FollowService();
    const count: number = await followService.getFollowerCount(request.token, User.fromDto(request.user)!);
    return {
        success: true,
        message: null,
        count: count
    };
}