import { FollowAndUnfollowResponse, FollowServiceGeneralRequest, User } from "tweeter-shared";
import { FollowService } from "../../model/service/FollowService";

export const handler = async (request: FollowServiceGeneralRequest): Promise<FollowAndUnfollowResponse> => {
    const followService = new FollowService();
    const [followerCount, followeeCount] = await followService.unfollow(request.token, User.fromDto(request.user)!);
    return {
        success: true,
        message: null,
        followerCount: followerCount,
        followeeCount: followeeCount
    };
};