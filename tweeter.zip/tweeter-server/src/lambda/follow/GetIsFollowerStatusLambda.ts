import { FollowerStatusRequest, FollowerStatusResponse, User } from "tweeter-shared";
import { FollowService } from "../../model/service/FollowService";


export const handler = async (request: FollowerStatusRequest): Promise<FollowerStatusResponse> => {
    const followService = new FollowService();
    const isFollower: boolean = await followService.getIsFollowerStatus(request.token, User.fromDto(request.user)!, User.fromDto(request.selectedUser)!);
    return {
        success: true,
        message: null,
        isFollower: isFollower
    };
}