import { ServerFacade } from "../network/ServerFacade";

export class Service {
    protected serverFacade =  new ServerFacade();
}