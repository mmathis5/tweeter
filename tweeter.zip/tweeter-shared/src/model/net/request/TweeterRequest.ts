export interface TweeterRequest {
}